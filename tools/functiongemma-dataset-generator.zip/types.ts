
export interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

export interface DatasetItem {
  id: string;
  user_content: string;
  tool_name: string;
  tool_arguments: string; // JSON string
  category?: string;
  created_at: number;
  validation?: ValidationResult;
}

export interface ToolSchema {
  name: string;
  description: string;
  parameters: any;
}

export interface GenerationConfig {
  count: number;
  category: string;
}

export enum IoTAction {
  GET_STATUS = 'tuya.get_status',
  SEND_COMMAND = 'tuya.send_command'
}
