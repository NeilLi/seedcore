
import React, { useState, useEffect } from 'react';
import { DatasetItem } from '../types';
import { normalizeEntry } from '../utils/validation';

interface DatasetListProps {
  items: DatasetItem[];
  onDelete: (id: string) => void;
  onUpdate: (item: DatasetItem) => void;
}

const DatasetList: React.FC<DatasetListProps> = ({ items, onDelete, onUpdate }) => {
  if (items.length === 0) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-20 text-center">
        <div className="w-20 h-20 bg-slate-800 rounded-full flex items-center justify-center mb-6">
          <i className="fas fa-folder-open text-3xl text-slate-600"></i>
        </div>
        <h2 className="text-xl font-medium text-slate-300 mb-2">Dataset is Empty</h2>
        <p className="text-slate-500 max-w-sm">Start by adding a manual entry or use the "Magic Generate" button to brainstorm synthetic IoT commands.</p>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-4 max-w-5xl mx-auto">
      {items.map((item) => (
        <DatasetEntry key={item.id} item={item} onDelete={onDelete} onUpdate={onUpdate} />
      ))}
    </div>
  );
};

interface DatasetEntryProps {
  item: DatasetItem;
  onDelete: (id: string) => void;
  onUpdate: (item: DatasetItem) => void;
}

const DatasetEntry: React.FC<DatasetEntryProps> = ({ item, onDelete, onUpdate }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [localItem, setLocalItem] = useState(item);

  // Sync with prop updates
  useEffect(() => {
    if (!isEditing) setLocalItem(item);
  }, [item, isEditing]);

  const handleSave = () => {
    onUpdate(localItem);
    setIsEditing(false);
  };

  const handleReset = () => {
    setLocalItem(item);
    setIsEditing(false);
  };

  const handleNormalize = () => {
    const normalized = normalizeEntry(localItem);
    setLocalItem(normalized);
  };

  const isValid = item.validation?.isValid;
  const errors = item.validation?.errors || [];

  return (
    <div className={`bg-slate-900 border ${isValid ? 'border-slate-800' : 'border-red-900/50'} rounded-xl overflow-hidden shadow-sm hover:border-slate-700 transition-all group`}>
      <div className="p-4 flex items-start justify-between">
        <div className="flex-1 space-y-4">
          {/* Natural Language Section */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
            <div>
              <label className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider mb-1 block">User Content</label>
              {isEditing ? (
                <textarea 
                  className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-sm focus:ring-1 focus:ring-indigo-500 outline-none text-slate-200"
                  rows={2}
                  value={localItem.user_content}
                  onChange={(e) => setLocalItem({...localItem, user_content: e.target.value})}
                />
              ) : (
                <p className="text-slate-200 text-sm font-medium leading-relaxed">{item.user_content}</p>
              )}
            </div>
            
            {!isValid && !isEditing && (
              <div className="bg-red-950/40 border border-red-900/50 px-3 py-1.5 rounded-lg flex items-center space-x-2 shrink-0 self-start sm:self-center">
                <i className="fas fa-exclamation-circle text-red-500"></i>
                <span className="text-[10px] font-bold text-red-400 uppercase tracking-widest">{errors.length} Error{errors.length > 1 ? 's' : ''}</span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Tool Name */}
            <div>
              <label className="text-[10px] font-bold text-amber-400 uppercase tracking-wider mb-1 block">Tool Name</label>
              {isEditing ? (
                <select 
                  className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-sm outline-none text-slate-200"
                  value={localItem.tool_name}
                  onChange={(e) => setLocalItem({...localItem, tool_name: e.target.value})}
                >
                  <option value="tuya.get_status">tuya.get_status</option>
                  <option value="tuya.send_command">tuya.send_command</option>
                </select>
              ) : (
                <code className="text-xs bg-slate-800 px-2 py-1 rounded text-amber-300 border border-amber-900/30">
                  {item.tool_name}
                </code>
              )}
            </div>

            {/* Actions (View Only) */}
            <div className="text-right flex items-center justify-end space-x-3 opacity-0 group-hover:opacity-100 transition-opacity">
               {!isEditing && (
                 <>
                  {!isValid && (
                    <button 
                      onClick={() => {
                        const normalized = normalizeEntry(item);
                        onUpdate(normalized);
                      }}
                      className="px-3 py-1 bg-purple-900/30 text-purple-400 border border-purple-800 rounded text-[10px] font-bold hover:bg-purple-800/40 transition-colors uppercase tracking-widest"
                    >
                      Auto Fix
                    </button>
                  )}
                  <button 
                    onClick={() => setIsEditing(true)}
                    className="p-2 text-slate-400 hover:text-indigo-400 transition-colors"
                  >
                    <i className="fas fa-edit"></i>
                  </button>
                  <button 
                    onClick={() => onDelete(item.id)}
                    className="p-2 text-slate-400 hover:text-red-400 transition-colors"
                  >
                    <i className="fas fa-trash-alt"></i>
                  </button>
                 </>
               )}
            </div>
          </div>

          {/* Validation Errors Display */}
          {!isValid && errors.length > 0 && (
            <div className="bg-red-950/20 border-l-2 border-red-600 p-3 space-y-1 rounded-r-lg">
              {errors.map((err, i) => (
                <div key={i} className="flex items-center space-x-2 text-[11px] text-red-400">
                  <span className="h-1 w-1 rounded-full bg-red-600"></span>
                  <span>{err}</span>
                </div>
              ))}
            </div>
          )}

          {/* Arguments Section */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block">Tool Arguments (JSON)</label>
              {isEditing && (
                <button 
                  onClick={handleNormalize}
                  className="text-[9px] font-bold text-slate-500 hover:text-emerald-400 uppercase tracking-widest flex items-center space-x-1"
                >
                  <i className="fas fa-wand-magic-sparkles"></i>
                  <span>Prettify & Normalize</span>
                </button>
              )}
            </div>
            {isEditing ? (
              <textarea 
                className="w-full bg-slate-950 border border-slate-700 rounded p-3 text-xs font-mono focus:ring-1 focus:ring-emerald-500 outline-none text-emerald-300"
                rows={6}
                value={localItem.tool_arguments}
                onChange={(e) => setLocalItem({...localItem, tool_arguments: e.target.value})}
              />
            ) : (
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 overflow-x-auto">
                <pre className="text-xs font-mono text-emerald-500/80">
                  {item.tool_arguments}
                </pre>
              </div>
            )}
          </div>
        </div>
      </div>

      {isEditing && (
        <div className="bg-slate-800/50 px-4 py-2 flex items-center justify-end space-x-3 border-t border-slate-800">
          <button 
            onClick={handleReset}
            className="text-xs font-medium text-slate-400 hover:text-slate-200 px-3 py-1"
          >
            Cancel
          </button>
          <button 
            onClick={handleSave}
            className="text-xs font-bold text-indigo-400 hover:text-indigo-300 bg-indigo-900/40 border border-indigo-700 px-4 py-1.5 rounded-md"
          >
            Save Changes
          </button>
        </div>
      )}
    </div>
  );
};

export default DatasetList;
