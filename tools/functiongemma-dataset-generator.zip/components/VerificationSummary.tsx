
import React, { useMemo } from 'react';
import { DatasetItem, IoTAction } from '../types';

interface VerificationSummaryProps {
  dataset: DatasetItem[];
  onNormalizeAll: () => void;
  onNavigateToItem: (id: string) => void;
}

const VerificationSummary: React.FC<VerificationSummaryProps> = ({ dataset, onNormalizeAll, onNavigateToItem }) => {
  const stats = useMemo(() => {
    const counts = {
      [IoTAction.GET_STATUS]: 0,
      [IoTAction.SEND_COMMAND]: 0,
      unknown: 0
    };
    let invalidCount = 0;
    const allErrors: { itemId: string; error: string; userContent: string }[] = [];

    dataset.forEach(item => {
      if (item.tool_name === IoTAction.GET_STATUS) counts[IoTAction.GET_STATUS]++;
      else if (item.tool_name === IoTAction.SEND_COMMAND) counts[IoTAction.SEND_COMMAND]++;
      else counts.unknown++;

      if (item.validation && !item.validation.isValid) {
        invalidCount++;
        item.validation.errors.forEach(err => {
          allErrors.push({
            itemId: item.id,
            error: err,
            userContent: item.user_content
          });
        });
      }
    });

    return { counts, invalidCount, allErrors };
  }, [dataset]);

  const healthyCount = dataset.length - stats.invalidCount;
  const healthPercentage = dataset.length > 0 ? (healthyCount / dataset.length) * 100 : 100;

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-8">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-100 mb-2">Verification Dashboard</h2>
          <p className="text-slate-400">Rigorously validating dataset structure for FunctionGemma training-readiness.</p>
        </div>
        {stats.invalidCount > 0 && (
          <button 
            onClick={onNormalizeAll}
            className="bg-indigo-600 hover:bg-indigo-500 px-6 py-2 rounded-lg font-bold text-sm flex items-center space-x-2 transition-all"
          >
            <i className="fas fa-magic"></i>
            <span>Fix All Invariants</span>
          </button>
        )}
      </header>

      {/* Hero Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
          <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 block">Dataset Health</label>
          <div className="flex items-end justify-between">
            <span className={`text-3xl font-bold ${healthPercentage === 100 ? 'text-emerald-400' : 'text-amber-400'}`}>{healthPercentage.toFixed(1)}%</span>
            <span className="text-slate-500 text-xs mb-1">{healthyCount} / {dataset.length} Healthy</span>
          </div>
          <div className="mt-4 h-2 bg-slate-800 rounded-full overflow-hidden">
            <div 
              className={`h-full transition-all duration-500 ${healthPercentage === 100 ? 'bg-emerald-500' : 'bg-amber-500'}`}
              style={{ width: `${healthPercentage}%` }}
            />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
          <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 block">Tool Distribution</label>
          <div className="space-y-2 mt-2">
            <div className="flex justify-between text-xs">
              <span className="text-blue-400 font-mono">tuya.get_status</span>
              <span className="text-slate-300">{stats.counts[IoTAction.GET_STATUS]}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-amber-400 font-mono">tuya.send_command</span>
              <span className="text-slate-300">{stats.counts[IoTAction.SEND_COMMAND]}</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
          <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 block">Active Issues</label>
          <div className="flex items-center space-x-3 mt-2">
             <span className={`text-3xl font-bold ${stats.invalidCount > 0 ? 'text-red-500' : 'text-emerald-500'}`}>
               {stats.allErrors.length}
             </span>
             <span className="text-slate-400 text-xs leading-tight">Semantic or structural violations detected</span>
          </div>
        </div>
      </div>

      {/* Detailed Issues List */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="font-bold text-slate-200 uppercase text-xs tracking-widest">Inconsistency Log</h3>
          <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-slate-400 font-mono">N={stats.allErrors.length}</span>
        </div>
        <div className="max-h-[500px] overflow-y-auto">
          {stats.allErrors.length === 0 ? (
            <div className="p-12 text-center">
              <i className="fas fa-check-circle text-4xl text-emerald-500/30 mb-4"></i>
              <p className="text-slate-400 text-sm">No issues found. Your dataset is canonical.</p>
            </div>
          ) : (
            <table className="w-full text-left">
              <thead className="bg-slate-950 text-[10px] font-bold text-slate-500 uppercase tracking-widest border-b border-slate-800">
                <tr>
                  <th className="px-6 py-3">Source Query</th>
                  <th className="px-6 py-3">Violation</th>
                  <th className="px-6 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {stats.allErrors.map((err, i) => (
                  <tr key={i} className="hover:bg-slate-800/50 transition-colors group">
                    <td className="px-6 py-4">
                      <p className="text-xs text-slate-300 line-clamp-1">{err.userContent}</p>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-2">
                        <span className="h-1.5 w-1.5 rounded-full bg-red-500"></span>
                        <span className="text-xs text-red-400">{err.error}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button 
                        onClick={() => onNavigateToItem(err.itemId)}
                        className="text-[10px] font-bold text-indigo-400 hover:text-indigo-300 uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Verification Guidelines Block */}
      <div className="bg-indigo-950/20 border border-indigo-900/40 rounded-2xl p-6">
        <h4 className="text-indigo-300 font-bold text-sm mb-4 flex items-center space-x-2">
          <i className="fas fa-info-circle"></i>
          <span>FunctionGemma Training Requirements</span>
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <h5 className="text-xs font-bold text-slate-300 uppercase tracking-wide">Structural Rigor</h5>
            <ul className="text-xs text-slate-400 space-y-1 list-disc pl-4">
              <li>Arguments MUST be encoded JSON strings.</li>
              <li>Tool names must exactly match <code>tuya.get_status</code> or <code>tuya.send_command</code>.</li>
              <li>No extraneous fields like <code>category</code> or <code>domain</code> inside the JSON call.</li>
            </ul>
          </div>
          <div className="space-y-2">
            <h5 className="text-xs font-bold text-slate-300 uppercase tracking-wide">Semantic Consistency</h5>
            <ul className="text-xs text-slate-400 space-y-1 list-disc pl-4">
              <li>Tuya DPs must always be in an array.</li>
              <li>Never use "on"/"off" as direct command values; use <code>{"{code: 'switch_led', value: true}"}</code>.</li>
              <li>Ensure <code>device_id</code> is consistently formatted across samples.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VerificationSummary;
