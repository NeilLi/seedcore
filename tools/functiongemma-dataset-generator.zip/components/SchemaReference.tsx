
import React from 'react';

const SchemaReference: React.FC = () => {
  return (
    <div className="p-8 max-w-4xl mx-auto space-y-10">
      <header>
        <h2 className="text-2xl font-bold text-slate-100 mb-2">Target Schema Registry</h2>
        <p className="text-slate-400">These are the tools the FunctionGemma model is being trained to call.</p>
      </header>

      <div className="space-y-8">
        {/* Tool 1 */}
        <section className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-2 bg-blue-900/30 rounded-lg">
              <i className="fas fa-eye text-blue-400"></i>
            </div>
            <h3 className="text-xl font-bold text-blue-300">tuya.get_status</h3>
          </div>
          <p className="text-slate-400 text-sm mb-6">Fetches current state of a device (on/off, brightness, sensor values).</p>
          
          <div className="bg-slate-950 rounded-lg p-4 border border-slate-800">
            <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3">JSON Parameters</h4>
            <pre className="text-xs font-mono text-slate-300">
{`{
  "type": "object",
  "properties": {
    "device_id": {
      "type": "string",
      "description": "Unique Tuya device identifier"
    }
  },
  "required": ["device_id"]
}`}
            </pre>
          </div>
        </section>

        {/* Tool 2 */}
        <section className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="p-2 bg-amber-900/30 rounded-lg">
              <i className="fas fa-bolt text-amber-400"></i>
            </div>
            <h3 className="text-xl font-bold text-amber-300">tuya.send_command</h3>
          </div>
          <p className="text-slate-400 text-sm mb-6">Executes actions on a device via Data Points (DPs).</p>
          
          <div className="bg-slate-950 rounded-lg p-4 border border-slate-800">
            <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3">JSON Parameters</h4>
            <pre className="text-xs font-mono text-slate-300">
{`{
  "type": "object",
  "properties": {
    "device_id": { "type": "string" },
    "commands": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "code": { "type": "string" },
          "value": { "type": "any" }
        },
        "required": ["code", "value"]
      }
    }
  },
  "required": ["device_id", "commands"]
}`}
            </pre>
          </div>
        </section>

        {/* DP Example Table */}
        <section>
          <h3 className="text-lg font-bold text-slate-200 mb-4">Common Tuya Data Point (DP) Examples</h3>
          <div className="overflow-hidden border border-slate-800 rounded-xl">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-900 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="px-4 py-3 font-semibold">Code</th>
                  <th className="px-4 py-3 font-semibold">Value Type</th>
                  <th className="px-4 py-3 font-semibold">Description</th>
                </tr>
              </thead>
              <tbody className="bg-slate-950 divide-y divide-slate-800">
                <tr>
                  <td className="px-4 py-3 font-mono text-emerald-400">switch_led</td>
                  <td className="px-4 py-3">Boolean</td>
                  <td className="px-4 py-3 text-slate-400">Turn device Power ON/OFF</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 font-mono text-emerald-400">bright_value</td>
                  <td className="px-4 py-3">Integer (0-1000)</td>
                  <td className="px-4 py-3 text-slate-400">Light brightness intensity</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 font-mono text-emerald-400">temp_value</td>
                  <td className="px-4 py-3">Integer (0-1000)</td>
                  <td className="px-4 py-3 text-slate-400">Color temperature (Warm to Cool)</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 font-mono text-emerald-400">work_mode</td>
                  <td className="px-4 py-3">String</td>
                  <td className="px-4 py-3 text-slate-400">Operation mode (white, colour, scene)</td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </div>
  );
};

export default SchemaReference;
