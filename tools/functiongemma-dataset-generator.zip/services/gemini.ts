
import { GoogleGenAI, Type } from "@google/genai";
import { DatasetItem, IoTAction } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

const DATASET_ITEM_SCHEMA = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      user_content: { type: Type.STRING, description: "The high-entropy natural language query from a user." },
      tool_name: { type: Type.STRING, description: "Must be tuya.get_status or tuya.send_command." },
      tool_arguments: { type: Type.STRING, description: "A JSON string of the arguments for the tool." }
    },
    required: ["user_content", "tool_name", "tool_arguments"]
  }
};

/**
 * Generates synthetic data in batches to ensure high quality and avoid token truncation.
 * Enforces "Boring Arguments, High-Entropy User Content" rule.
 */
export async function generateSyntheticData(targetCount: number, focus: string): Promise<Partial<DatasetItem>[]> {
  const batchSize = 50;
  const numBatches = Math.ceil(targetCount / batchSize);
  
  const generateBatch = async (count: number) => {
    const prompt = `
      Act as an expert IoT data engineer specializing in FunctionGemma fine-tuning. 
      Generate ${count} training samples for translating natural language to Tuya IoT calls.
      
      GOLD-STANDARD DATASET RULES:
      1. ONE INTENT -> ONE TOOL -> ONE CALL: Each sample must represent a single, atomic action. Never call multiple tools.
      2. CANONICAL ARGUMENTS ONLY: tuya.send_command MUST use {"device_id": "string", "commands": [{"code": "string", "value": any}]}.
      3. NO SHORTCUTS: Never use "commands": "on". Commands MUST be an array of DP objects.
      4. NO REASONING: tool_arguments must NEVER contain logic, reasoning, or natural language (e.g., "turn on if dark"). It must be PURE structured data.
      5. BORING ARGUMENTS: Keep tool_arguments repetitive and stable. Variation belongs ONLY in the user_content.
      6. HIGH-ENTROPY NL: The "user_content" should be very diverse—casual, formal, typo-ridden, complex, or extremely brief.
      
      TUYA DP CODES: "switch_led" (bool), "bright_value" (int 0-1000), "temp_value" (int 0-1000), "work_mode" (string: white, colour, scene, music).
      
      Target Focus: ${focus}.
      Output must be a valid JSON array matching the requested schema.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: DATASET_ITEM_SCHEMA
      }
    });

    const text = response.text || "[]";
    return JSON.parse(text) as Partial<DatasetItem>[];
  };

  try {
    const batchPromises = Array.from({ length: numBatches }, (_, i) => {
      const count = i === numBatches - 1 ? targetCount - (batchSize * i) : batchSize;
      return generateBatch(count);
    });

    const results = await Promise.all(batchPromises);
    return results.flat();
  } catch (error) {
    console.error("Gemini Generation Error:", error);
    throw error;
  }
}
