
import { DatasetItem, IoTAction, ValidationResult } from "../types";

export function validateEntry(item: DatasetItem): ValidationResult {
  const errors: string[] = [];

  // 1. Basic field presence
  if (!item.user_content.trim()) errors.push("User content is empty");
  if (!item.tool_name.trim()) errors.push("Tool name is missing");

  // 2. JSON structural check
  let args: any;
  try {
    args = JSON.parse(item.tool_arguments);
    if (typeof args !== 'object' || args === null || Array.isArray(args)) {
      errors.push("Tool arguments must be a JSON object");
    }
  } catch (e) {
    errors.push("Tool arguments is not valid JSON");
    return { isValid: false, errors };
  }

  // 3. Semantic Validation for FunctionGemma (Gold Rules)
  // Check for reasoning / NL leakage in arguments
  const argsStr = JSON.stringify(args).toLowerCase();
  const reasoningKeywords = [" if ", " when ", " because ", " so ", " turn ", " light "];
  if (reasoningKeywords.some(kw => argsStr.includes(kw))) {
    errors.push("Semantic drift: Natural language / reasoning detected in tool_arguments");
  }

  if (item.tool_name === IoTAction.GET_STATUS) {
    if (typeof args.device_id !== 'string' || !args.device_id) {
      errors.push("tuya.get_status requires a string 'device_id'");
    }
    if (Object.keys(args).length > 1) {
      errors.push("tuya.get_status contains extraneous keys (violation: Boring Arguments)");
    }
  } else if (item.tool_name === IoTAction.SEND_COMMAND) {
    if (typeof args.device_id !== 'string' || !args.device_id) {
      errors.push("tuya.send_command requires a string 'device_id'");
    }
    if (!Array.isArray(args.commands)) {
      errors.push("tuya.send_command violation: 'commands' must be an array (Shortcut detected)");
    } else {
      args.commands.forEach((cmd: any, idx: number) => {
        if (typeof cmd !== 'object' || cmd === null) {
          errors.push(`Command at index ${idx} is not an object (Canonical format violation)`);
        } else {
          if (typeof cmd.code !== 'string' || !cmd.code) {
            errors.push(`Command at index ${idx} missing string 'code'`);
          }
          if (cmd.value === undefined) {
            errors.push(`Command at index ${idx} missing 'value'`);
          }
          // Check for forbidden fields that drift from schema
          if (cmd.device_id) {
            errors.push(`Command at index ${idx} contains redundant 'device_id'`);
          }
        }
      });
    }
  } else {
    errors.push(`Unknown tool name: ${item.tool_name}`);
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

export function normalizeEntry(item: DatasetItem): DatasetItem {
  try {
    const args = JSON.parse(item.tool_arguments);
    const normalizedArgs: any = {};
    
    // Always preserve device_id at top level
    normalizedArgs.device_id = typeof args.device_id === 'string' ? args.device_id : "unknown_device";

    if (item.tool_name === IoTAction.SEND_COMMAND) {
      let rawCommands = args.commands;
      
      // Fix shortcuts
      if (rawCommands === undefined) rawCommands = [];
      if (!Array.isArray(rawCommands)) rawCommands = [rawCommands];
      
      normalizedArgs.commands = rawCommands.map((cmd: any) => {
        // If it's a shortcut string
        if (typeof cmd === 'string') {
          const val = cmd.toLowerCase();
          if (val === 'on' || val === 'true') return { code: 'switch_led', value: true };
          if (val === 'off' || val === 'false') return { code: 'switch_led', value: false };
          return { code: 'unknown_code', value: cmd };
        }
        
        // If it's a valid object, strip any logic or extra fields
        if (cmd && typeof cmd === 'object') {
          return {
            code: typeof cmd.code === 'string' ? cmd.code : 'unknown_code',
            value: cmd.value !== undefined ? cmd.value : null
          };
        }
        
        return { code: 'unknown_code', value: cmd };
      });
    }

    return {
      ...item,
      tool_arguments: JSON.stringify(normalizedArgs, null, 2)
    };
  } catch (e) {
    return item;
  }
}
