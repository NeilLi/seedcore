
import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { DatasetItem, IoTAction } from './types';
import { generateSyntheticData } from './services/gemini';
import DatasetList from './components/DatasetList';
import SchemaReference from './components/SchemaReference';
import VerificationSummary from './components/VerificationSummary';
import { validateEntry, normalizeEntry } from './utils/validation';
import { v4 as uuidv4 } from 'uuid';

const App: React.FC = () => {
  const [dataset, setDataset] = useState<DatasetItem[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'dataset' | 'schemas' | 'verification'>('dataset');

  // Load from local storage on mount
  useEffect(() => {
    const saved = localStorage.getItem('function_gemma_dataset');
    if (saved) {
      try {
        const parsed: DatasetItem[] = JSON.parse(saved);
        // Run initial validation on load
        setDataset(parsed.map(item => ({ ...item, validation: validateEntry(item) })));
      } catch (e) {
        console.error("Failed to parse local storage", e);
      }
    }
  }, []);

  // Save to local storage on change
  useEffect(() => {
    localStorage.setItem('function_gemma_dataset', JSON.stringify(dataset));
  }, [dataset]);

  const handleGenerate = async () => {
    setIsGenerating(true);
    const TARGET_COUNT = 500;
    try {
      const results = await generateSyntheticData(TARGET_COUNT, "Smart lighting, climate control, and home security");
      const newItems: DatasetItem[] = results.map(r => {
        const item: DatasetItem = {
          id: uuidv4(),
          user_content: r.user_content || '',
          tool_name: r.tool_name || IoTAction.GET_STATUS,
          tool_arguments: r.tool_arguments || '{}',
          created_at: Date.now()
        };
        return { ...item, validation: validateEntry(item) };
      });
      setDataset(prev => [...newItems, ...prev]);
    } catch (error) {
      alert("Failed to generate data. Check console/API key and rate limits.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleAddItem = () => {
    const newItem: DatasetItem = {
      id: uuidv4(),
      user_content: "New user query...",
      tool_name: IoTAction.SEND_COMMAND,
      tool_arguments: JSON.stringify({ device_id: "dev_id", commands: [{ code: "switch_led", value: true }] }, null, 2),
      created_at: Date.now()
    };
    setDataset(prev => [{ ...newItem, validation: validateEntry(newItem) }, ...prev]);
  };

  const handleDelete = (id: string) => {
    setDataset(prev => prev.filter(item => item.id !== id));
  };

  const handleUpdate = (updatedItem: DatasetItem) => {
    const validated = { ...updatedItem, validation: validateEntry(updatedItem) };
    setDataset(prev => prev.map(item => item.id === updatedItem.id ? validated : item));
  };

  const handleStrictSanitizeAll = () => {
    setDataset(prev => prev.map(item => {
      const normalized = normalizeEntry(item);
      return { ...normalized, validation: validateEntry(normalized) };
    }));
  };

  const handleExport = () => {
    const content = dataset
      .map(item => JSON.stringify({
        user_content: item.user_content,
        tool_name: item.tool_name,
        tool_arguments: item.tool_arguments
      }))
      .join('\n');
    
    const blob = new Blob([content], { type: 'application/x-jsonlines' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `intent_tool_dataset_${new Date().toISOString().split('T')[0]}.jsonl`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredDataset = useMemo(() => {
    return dataset.filter(item => 
      item.user_content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.tool_name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [dataset, searchTerm]);

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      {/* Header */}
      <header className="bg-slate-800 border-b border-slate-700 p-4 flex items-center justify-between sticky top-0 z-10 shadow-lg shrink-0">
        <div className="flex items-center space-x-3">
          <div className="bg-indigo-600 p-2 rounded-lg">
            <i className="fas fa-microchip text-xl"></i>
          </div>
          <div className="flex flex-col">
            <h1 className="text-xl font-bold tracking-tight leading-none">FunctionGemma <span className="text-indigo-400">Dataset Generator</span></h1>
            <span className="text-[10px] text-slate-500 font-medium uppercase tracking-widest mt-1">IoT Intent Compiler Pipeline</span>
          </div>
        </div>
        <div className="flex space-x-2">
          <button 
            onClick={handleGenerate}
            disabled={isGenerating}
            className={`flex items-center space-x-2 px-4 py-2 rounded-md font-medium transition-all ${isGenerating ? 'bg-slate-700 cursor-not-allowed opacity-80' : 'bg-indigo-600 hover:bg-indigo-500 shadow-lg shadow-indigo-900/20'}`}
          >
            {isGenerating ? <i className="fas fa-spinner fa-spin"></i> : <i className="fas fa-wand-magic-sparkles"></i>}
            <span>{isGenerating ? 'Processing 500 Units...' : 'Magic Generate (500)'}</span>
          </button>
          <button 
            onClick={handleStrictSanitizeAll}
            className="flex items-center space-x-2 px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded-md font-medium group"
            title="Enforce canonical formatting and remove reasoning artifacts"
          >
            <i className="fas fa-shield-halved text-purple-400 group-hover:scale-110 transition-transform"></i>
            <span>Strict Sanitize</span>
          </button>
          <button 
            onClick={handleAddItem}
            className="flex items-center space-x-2 px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded-md font-medium"
          >
            <i className="fas fa-plus text-green-400"></i>
            <span>Add Entry</span>
          </button>
          <button 
            onClick={handleExport}
            disabled={dataset.length === 0}
            className="flex items-center space-x-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 rounded-md font-medium disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <i className="fas fa-download"></i>
            <span>Export JSONL</span>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar Nav */}
        <nav className="w-64 bg-slate-900 border-r border-slate-800 p-4 flex flex-col space-y-2 shrink-0">
          <button 
            onClick={() => setActiveTab('dataset')}
            className={`flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeTab === 'dataset' ? 'bg-indigo-900/40 text-indigo-300 border border-indigo-700/50' : 'hover:bg-slate-800 text-slate-400'}`}
          >
            <i className="fas fa-database w-5"></i>
            <span>Dataset ({dataset.length})</span>
          </button>
          <button 
            onClick={() => setActiveTab('verification')}
            className={`flex items-center justify-between px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeTab === 'verification' ? 'bg-indigo-900/40 text-indigo-300 border border-indigo-700/50' : 'hover:bg-slate-800 text-slate-400'}`}
          >
            <div className="flex items-center space-x-3">
              <i className="fas fa-clipboard-check w-5"></i>
              <span>Verification</span>
            </div>
            {dataset.some(i => i.validation && !i.validation.isValid) && (
              <span className="h-2 w-2 rounded-full bg-red-500 shadow-sm shadow-red-900 animate-pulse"></span>
            )}
          </button>
          <button 
            onClick={() => setActiveTab('schemas')}
            className={`flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${activeTab === 'schemas' ? 'bg-indigo-900/40 text-indigo-300 border border-indigo-700/50' : 'hover:bg-slate-800 text-slate-400'}`}
          >
            <i className="fas fa-code-branch w-5"></i>
            <span>Schema Reference</span>
          </button>
          
          <div className="pt-6 mt-6 border-t border-slate-800">
            <h3 className="px-4 text-xs font-semibold text-slate-500 uppercase tracking-wider mb-4">Filters</h3>
            <div className="px-4">
               <div className="relative">
                 <i className="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-xs"></i>
                 <input 
                  type="text" 
                  placeholder="Filter items..." 
                  className="w-full bg-slate-800 border border-slate-700 rounded-md py-2 pl-9 pr-4 text-xs focus:ring-1 focus:ring-indigo-500 outline-none transition-all"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                 />
               </div>
            </div>
          </div>
        </nav>

        {/* Content Tabs */}
        <main className="flex-1 bg-slate-950 overflow-y-auto">
          {activeTab === 'dataset' ? (
            <DatasetList 
              items={filteredDataset} 
              onDelete={handleDelete} 
              onUpdate={handleUpdate} 
            />
          ) : activeTab === 'verification' ? (
            <VerificationSummary 
              dataset={dataset} 
              onNormalizeAll={handleStrictSanitizeAll}
              onNavigateToItem={(id) => {
                setActiveTab('dataset');
                setSearchTerm(id); // Highlight item
              }}
            />
          ) : (
            <SchemaReference />
          )}
        </main>
      </div>

      {/* Footer / Status Bar */}
      <footer className="bg-slate-800 border-t border-slate-700 px-4 py-2 flex items-center justify-between text-[10px] text-slate-400 uppercase tracking-widest shrink-0">
        <div className="flex items-center space-x-4">
          <span>Target: FunctionGemma-IT</span>
          <span>Invariants: Strictly Canonical DPs</span>
          <span className="flex items-center space-x-1">
            <span className={`h-1.5 w-1.5 rounded-full ${dataset.every(i => i.validation?.isValid) ? 'bg-emerald-500' : 'bg-red-500'}`}></span>
            <span>Dataset Health: {dataset.every(i => i.validation?.isValid) ? 'Stable' : 'Unstable'}</span>
          </span>
        </div>
        <div>
          {dataset.length} Samples Generated
        </div>
      </footer>
    </div>
  );
};

export default App;
