import React, { useRef, useMemo } from 'react';
import { Canvas } from '@react-three/fiber';
import { 
  MeshReflectorMaterial, 
  Text,
  PerspectiveCamera,
  Environment,
  Float,
  ContactShadows
} from '@react-three/drei';
import * as THREE from 'three';
import { Room, Agent } from '../types';

const GRID_SCALE = 0.4;

// --- Sub-Component: Tactical Room Zone ---
function RoomZone({ room, themeColor }: { room: Room, themeColor: string }) {
  if (!room || !room.topLeft || !room.bottomRight) return null;

  const width = room.bottomRight.x - room.topLeft.x + 1;
  const height = room.bottomRight.y - room.topLeft.y + 1;

  const x = (room.topLeft.x * GRID_SCALE) - (16 * GRID_SCALE) + (width * GRID_SCALE / 2);
  const z = (room.topLeft.y * GRID_SCALE) - (8 * GRID_SCALE) + (height * GRID_SCALE / 2);

  return (
    <group position={[x, 0, z]}>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, 0]}>
        <planeGeometry args={[width * GRID_SCALE, height * GRID_SCALE]} />
        {/* Adjusted opacity for better blending with background */}
        <meshStandardMaterial 
            color={themeColor} 
            transparent 
            opacity={0.12} 
            emissive={themeColor} 
            emissiveIntensity={4} 
            toneMapped={false} 
        />
      </mesh>
      <Text position={[0, 1.5, 0]} fontSize={0.22} color={themeColor} fillOpacity={0.8}>
        {room.name?.toUpperCase() || "ZONE"}
      </Text>
    </group>
  );
}

export function VirtualRealityLayer({ 
  atmosphere, 
  enabled, 
  rooms, 
  agents,
  backgroundImage 
}: { 
  atmosphere: string, enabled: boolean, rooms: Room[], agents: Agent[], backgroundImage?: string 
}) {
  const isGolden = atmosphere === 'GOLDEN_HOUR';
  const themeColor = isGolden ? "#fbbf24" : "#22d3ee";

  const particles = useMemo(() => [...Array(25)].map(() => ({
    pos: [(Math.random() - 0.5) * 35, Math.random() * 8, (Math.random() - 0.5) * 20] as [number, number, number],
  })), []);

  return (
    <div 
      className="absolute inset-0 z-10 transition-opacity duration-1000" 
      style={{ 
        visibility: enabled ? 'visible' : 'hidden', 
        opacity: enabled ? 1 : 0 
      }}
    >
      {/* HTML Background Layer (CORS-Safe & Performance Optimized) */}
      <div className="absolute inset-0 z-0">
        {backgroundImage ? (
          <img 
            src={backgroundImage} 
            className="w-full h-full object-cover opacity-45 grayscale-[0.4]" 
            alt="Atmosphere"
            onError={(e) => {
               // Fail gracefully if image path is bad
               e.currentTarget.style.display = 'none';
            }}
          />
        ) : (
          <div className={`w-full h-full ${isGolden ? 'bg-orange-950/20' : 'bg-slate-950/40'}`} />
        )}
        <div className="absolute inset-0 shadow-[inset_0_0_200px_rgba(0,0,0,0.9)]" />
        <div className="absolute inset-0 ring-1 ring-white/5" />
      </div>

      {/* Lightweight WebGL Overlay */}
      <Canvas
        gl={{ preserveDrawingBuffer: true, antialias: true, alpha: true }}
        dpr={[1, 1.5]}
        frameloop={enabled ? 'always' : 'never'}
        // Critical: Set clear color to transparent so HTML background shows
        onCreated={({ gl }) => gl.setClearColor(new THREE.Color('#000000'), 0)}
      >
        <PerspectiveCamera makeDefault position={[0, 10, 20]} fov={32} />
        
        <fog attach="fog" args={['#000000', 12, 35]} />

        <group>
          {/* Obsidian Floor: High transparency to see background image */}
          <mesh rotation={[-Math.PI / 2, 0, 0]}>
            <planeGeometry args={[100, 100]} />
            <MeshReflectorMaterial
              blur={[300, 100]}
              resolution={512}
              mixBlur={1}
              mixStrength={20}
              roughness={0.9}
              color="#050505"
              metalness={0.5}
              transparent={true}
              opacity={0.3} // See-through floor
            />
          </mesh>

          {rooms?.map((room) => <RoomZone key={room.id} room={room} themeColor={themeColor} />)}

          {agents?.map((agent) => (
             <mesh key={agent.id} position={[(agent.position?.x * GRID_SCALE) - (16 * GRID_SCALE), 0.5, (agent.position?.y * GRID_SCALE) - (8 * GRID_SCALE)]}>
               <sphereGeometry args={[0.12, 16, 16]} />
               <meshStandardMaterial emissive={themeColor} emissiveIntensity={10} toneMapped={false} />
             </mesh>
          ))}

          {particles.map((p, i) => (
            <Float key={i} speed={2} floatIntensity={1}>
              <mesh position={p.pos}>
                <sphereGeometry args={[0.02, 8, 8]} />
                <meshStandardMaterial emissive={themeColor} emissiveIntensity={6} toneMapped={false} transparent opacity={0.4} />
              </mesh>
            </Float>
          ))}
        </group>

        <Environment preset="night" />
        <ambientLight intensity={0.4} />
      </Canvas>
    </div>
  );
}